var works = [
  { 
    title: "E-commerce",
    pic: "images/bike-shop.png",
    url: "https://bike-shop-toronto.herokuapp.com"
  },
  {
    title: "Blog",
    pic: "images/fishing.png",
    url: "https://fishing-with-me.herokuapp.com/"
  },
  {
    title: "Indian restaurant in Germany ",
    pic: "images/ganesha.png",
    url: "http://www.ganesharestaurant.de/ganesha_contact_en.html"
  },
  { 
    title: "Gold Gym",
    pic: "images/gold.png",
    url: "http://www.goldsgym.com/"
  },
  {
    title: "AnaPan new bakery in town ",
    pic: "images/ana.png",
    url: "http://www.anapan.ro/"
  },
  {
    title: "Thrace Greiner Plastics",
    pic: "images/thrace.png"
  }

];
